from django.urls import path
from .views import request_payment_token, payment_callback

urlpatterns = [
    path("payment/request/", request_payment_token, name="payment_request"),
    path("payment/callback/", payment_callback, name="payment_callback"),
]
