import requests
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, HttpResponseBadRequest

# مقادیر ثابت درگاه پرداخت سامان (SEP)
TERMINAL_ID = "15445928"  # شماره ترمینال شما
REDIRECT_URL = "https://yourdomain.com/payment/callback/"  # آدرس بازگشت سایت شما


def request_payment_token(request):
    """
    مرحله اول: ارسال اطلاعات به سامان جهت دریافت توکن و نمایش فرم هدایت به درگاه
    """
    # در سناریوی واقعی، این مقادیر را از سبد خرید یا دیتابیس دریافت کنید
    amount = 12000
    res_num = "1qaz_WSX"  # شناسه خرید منحصر به فرد شما
    cell_number = "09336514443"

    payload = {
        "action": "token",
        "TerminalId": TERMINAL_ID,
        "Amount": amount,
        "ResNum": res_num,
        "RedirectUrl": REDIRECT_URL,
        "CellNumber": cell_number,
    }

    headers = {"Content-Type": "application/json"}
    token_url = "https://sep.shaparak.ir/OnlinePG/OnlinePG"

    try:
        response = requests.post(token_url, json=payload, headers=headers)
        response_data = response.json()

        # بررسی موفقیت‌آمیز بودن دریافت توکن
        if response_data.get("status") == 1 and "token" in response_data:
            token = response_data["token"]

            # ارسال توکن به قالب HTML جهت هدایت خودکار کاربر
            context = {
                "token": token,
                "action_url": token_url,
            }
            return render(request, "payment/redirect_to_gateway.html", context)
        else:
            error_msg = response_data.get(
                "errorDesc", "خطا در دریافت توکن پرداخت"
            )
            return JsonResponse(
                {"status": "error", "message": error_msg}, status=400
            )

    except requests.RequestException as e:
        return JsonResponse(
            {"status": "error", "message": f"خطا در ارتباط با درگاه: {str(e)}"},
            status=500,
        )


@csrf_exempt  # درگاه پرداخت سامان اطلاعات را به صورت POST به سایت شما بازمی‌گرداند
def payment_callback(request):
    """
    مرحله دوم: دریافت پاسخ از درگاه پرداخت و انجام عملیات تایید تراکنش (Verify)
    """
    if request.method != "POST":
        return HttpResponseBadRequest("فقط متد POST مجاز است")

    # دریافت اطلاعات ارسال شده از سمت درگاه (سامان معمولا به صورت Form Data ارسال می‌کند)
    ref_num = request.POST.get("RefNum")
    res_num = request.POST.get("ResNum")
    state = request.POST.get("State")

    # بررسی وضعیت کلی تراکنش بازگشتی
    if state == "OK" and ref_num:
        # مرحله تایید تراکنش (Verify)
        verify_url = "https://sep.shaparak.ir/verifyTxnRandomSessionkey/ipg/VerifyTransaction"
        verify_payload = {
            "RefNum": ref_num,
            "TerminalNumber": TERMINAL_ID,  # یا ترمینال تعریف شده برای وریفای
        }
        verify_headers = {"Content-Type": "application/json"}

        try:
            verify_response = requests.post(
                verify_url, json=verify_payload, headers=verify_headers
            )
            verify_data = verify_response.json()

            # به طور معمول، سامان در صورت موفقیت وریفای، مبلغ تراکنش (Amount) را در فیلد تراکنش باز می‌گرداند
            # مقدار برگشتی عددی بزرگتر از ۰ خواهد بود (مثلا معادل Amount تراکنش)
            if (
                verify_response.status_code == 200
                and int(verify_data.get("ResultCode", -1)) == 0
            ):
                # در اینجا عملیات موفقیت‌آمیز بوده است؛ دیتابیس خود را بروزرسانی کنید.
                return render(
                    request,
                    "payment/success.html",
                    {"ref_num": ref_num, "res_num": res_num},
                )
            else:
                # تراکنش تایید نشد (باید به کاربر خطا نمایش داده شود و در صورت کسر وجه، خودکار برگشت می‌خورد)
                return render(
                    request,
                    "payment/failed.html",
                    {"message": "تایید تراکنش ناموفق بود."},
                )

        except requests.RequestException as e:
            return render(
                request,
                "payment/failed.html",
                {"message": "خطا در ارتباط با سرور بانک جهت تایید تراکنش"},
            )
    else:
        # کاربر پرداخت را لغو کرده یا تراکنش ناموفق بوده است
        return render(
            request,
            "payment/failed.html",
            {
                "message": f"تراکنش ناموفق بود یا توسط کاربر لغو شد. کد وضعیت: {state}"
            },
        )
