﻿using Microsoft.AspNetCore.Mvc;
using Sample_Code_OnlinePG_With_Token.Models;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Linq;
using System.Web;
using System.Text.Json;
using RestSharp;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;



namespace Sample_Code_OnlinePG_With_Token.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private SqlConnection con;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public ActionResult Token()
        {
            return View();
        }
        public ViewResult Token(Payment ent)
        {
            string Termid = ent.txtTid;
            string Amount = ent.txtAmount;
            string Resnum = ent.txtResnum;
            string RedirectURL = ent.txtUrl;
            string CellNumber = ent.txtCellNumber;

            var client = new RestSharp.RestClient("https://sep.shaparak.ir/OnlinePG/OnlinePG");
            var requset = new RestRequest(Method.POST);
            requset.AddHeader("cache-control", "no-cache");
            requset.AddHeader("Connection", "keep-alive");
            requset.AddHeader("Content-Length", "173");
            requset.AddHeader("Accept-Encoding", "gzip, deflate");
            requset.AddHeader("Host", "sep.shaparak.ir");
            //request.AddHeader("Postman-Token", "30a4bab3-547d-49af-9f01-c05ba5ef12d2,3467121b-e696-45bf-b8ff-ddf343536300");
            requset.AddHeader("Cache-Control", "no-cache");
            requset.AddHeader("Accept", "*/*");
            requset.AddHeader("User-Agent", "PostmanRuntime/7.16.3");
            requset.AddHeader("Content-Type", "application/json");
            requset.AddParameter("undefined", "{\r\n  \"Action\": \"Token\",\r\n  \"TerminalId\": \"" + Termid + "\",\r\n  \"RedirectUrl\": \"" + RedirectURL + "\",\r\n  \"ResNum\": \"" + Resnum + "\",\r\n  \"Amount\": \"" + Amount + "\",\r\n  \"CellNumber\":\"" + CellNumber + "\"\r\n}", ParameterType.RequestBody);


            IRestResponse response = client.Execute(requset);
            string resp = response.Content;
            string statecode = response.StatusCode.ToString();
            dynamic detail = JObject.Parse(resp);

               if (statecode == "OK")
                 {
                  string token = detail["token"];
                ViewBag.Token = token;
                ViewBag.redirectURL = RedirectURL;
                 }
            return ( View(viewName: "Prepare"));

        }
        public ActionResult Return()
        {
            ViewBag.BankName = "درگاه بانک سامان";
            try
            {
                // بررسی وجود استیت ارسالی از درگاه
                // در صورت عدم وجود خطا را نمایش می دهیم
                if (Request.Form["state"].ToString().Equals(string.Empty))
                {
                    //ViewBag.Message = "خريد شما توسط بانک تاييد شده است اما رسيد ديجيتالي شما تاييد نگشت! مشکلي در فرايند رزرو خريد شما پيش آمده است";
                    ViewBag.Message = "پاسخی از درگاه بانکی دریافت نشد";
                    ViewBag.SaleReferenceId = "**************";
                }

                // بررسی وجود رف نام ارسالی از درگاه
                // در صورت عدم وجود خطا را نمایش می دهیم
                else if (Request.Form["RefNum"].ToString().Equals(string.Empty) && Request.Form["state"].ToString().Equals(string.Empty))
                {
                    ViewBag.Message = "فرايند انتقال وجه با موفقيت انجام شده است اما فرايند تاييد رسيد ديجيتالي با خطا مواجه گشت";
                    ViewBag.SaleReferenceId = "**************";
                }

                // بررسی وجود رس نام ارسالی از درگاه
                // در صورت عدم وجود خطا را نمایش می دهیم
                else if (Request.Form["ResNum"].ToString().Equals(string.Empty) && Request.Form["state"].ToString().Equals(string.Empty))
                {
                    ViewBag.Message = "خطا در برقرار ارتباط با بانک";
                    ViewBag.SaleReferenceId = "**************";
                }
                else
                {
                    // تغییر های مورد تعریف شده برای قرار دادن اطلاعات دریافتی از درگاه
                    string refrenceNumber = string.Empty;
                    string reservationNumber = string.Empty;
                    string transactionState = string.Empty;
                    string traceNumber = string.Empty;
                    string terminal = string.Empty;

                    // کد سفارش که به صورت عدد و حروف می باشد
                    refrenceNumber = Request.Form["RefNum"].ToString();

                    // کد ارسالی از طرف سایت که شماره آی دی همان اطلاعات ثبتی در هنگام اتصال به درگاه
                    reservationNumber = Request.Form["ResNum"].ToString();

                    // وضعیت پرداخت
                    transactionState = Request.Form["state"].ToString();

                    // شماره پیگیری
                    traceNumber = Request.Form["TraceNo"].ToString();
                    //شماره ترمینال
                    terminal = Request.Form["MID"];
                    //آی دی که به ازای هر resnum برای مشتری در دیتابیس ذخیره شده است
                    //long paymentId = Convert.ToInt32(reservationNumber);

                    if (transactionState.Equals("OK"))
                    {
                        ///////////////////////////////////////////////////////////////////////////////////
                        //   *** IMPORTANT  ****   ATTENTION
                        // Here you should check refrenceNumber in your DataBase tp prevent double spending
                        ///////////////////////////////////////////////////////////////////////////////////

                        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                        //Payment
                        var client = new RestSharp.RestClient("https://sep.shaparak.ir/VerifyTxnRandomSessionkey/ipg/VerifyTransaction");
                        var requset = new RestRequest(Method.POST);
                        requset.AddHeader("cache-control", "no-cache");
                        requset.AddHeader("Connection", "keep-alive");
                        requset.AddHeader("Content-Length", "173");
                        requset.AddHeader("Accept-Encoding", "gzip, deflate");
                        requset.AddHeader("Host", "sep.shaparak.ir");
                        requset.AddHeader("Cache-Control", "no-cache");
                        requset.AddHeader("Accept", "*/*");
                        requset.AddHeader("User-Agent", "PostmanRuntime/7.16.3");
                        requset.AddHeader("Content-Type", "application/json");
                        requset.AddParameter("undefined", "{\r\n  \"terminalnumber\": \"" + terminal + "\",\r\n  \"refnum\": \"" + refrenceNumber + "\"}", ParameterType.RequestBody);


                        IRestResponse response = client.Execute(requset);
                        string resp = response.Content;
                        string statecode = response.StatusCode.ToString();
                        dynamic detail = JObject.Parse(resp);
                        var result = detail["ResultCode"];

                        if (result > 0)
                        {

                            ViewBag.Message = "پرداخت با موفقیت انجام شد.";
                            ViewBag.SaleReferenceId = traceNumber;
                            ViewBag.RefrenceNumber = refrenceNumber;
                        }
                        else
                        {
                            //// پرداخت ناموفق بوده و اطلاعات دریافتی را در دیتابیس ثبت می کنیم
                            //UpdatePayment(paymentId, result.ToString(), 0, refrenceNumber, false);

                            ViewBag.message = PaymentResult.Saman(transactionState);
                            ViewBag.SaleReferenceId = "**************";
                        }
                        var DbRecord = new PayResult();
                        DbRecord.Refnum = refrenceNumber;
                        DbRecord.Resnum = reservationNumber;
                        DbRecord.State = statecode;
                        DbRecord.TraceNo = traceNumber;
                        if (InsertToDb(DbRecord))
                        {
                            ViewBag.DatabaseState = "DB inserted";
                        }
                        else
                        {
                            ViewBag.DatabaseState = "DB not inserted";
                        }
                        
                    }
                    else
                    {
                        //// پرداخت ناموفق بوده و اطلاعات دریافتی را در دیتابیس ثبت می کنیم
                        //UpdatePayment(paymentId, transactionState, 0, refrenceNumber, false);

                        if (!String.IsNullOrEmpty(PaymentResult.Saman(transactionState)))
                        {
                            ViewBag.Message = PaymentResult.Saman(transactionState);
                        }
                        else
                        {
                            ViewBag.Message = "متاسفانه بانک خريد شما را تاييد نکرده است";
                        }
                        ViewBag.SaleReferenceId = "**************";

                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.SaleReferenceId = "**************";
                ViewBag.Message = "مشکلی در پرداخت به وجود آمده است ، در صورتیکه وجه پرداختی از حساب بانکی شما کسر شده است آن مبلغ به صورت خودکار برگشت داده خواهد شد";
            }

            return View();
        }



        private void connection()
        {
            try
            {
                string constr = "Server=SSP04\\SQLEXPRESS;Initial Catalog=InternetTrans;Integrated Security=True;";
                con = new SqlConnection(constr);
            }
            catch (global::System.Exception)
            {

                throw;
            }


        }
        public bool InsertToDb(PayResult obj)
        {
            connection();
            SqlCommand com = new SqlCommand("AddTrans", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Refnum", obj.Refnum);
            com.Parameters.AddWithValue("@Resnum", obj.Resnum);
            com.Parameters.AddWithValue("@State", obj.State);
            com.Parameters.AddWithValue("@TraceNo", obj.TraceNo);
            con.Open();
            int i = com.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}