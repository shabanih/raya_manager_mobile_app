﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Result.aspx.cs" Inherits="OnlinePG_sample01.Result" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="StyleSheet1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <asp:Label ID="lblResponse" runat="server" Text=""></asp:Label>

    <form id="form1" runat="server">
        <div>
            <table>
                <tr>
                    <th>Item:</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td class="fitwidth">TerminalId:</td>
                    <td class="fitwidth">
                        <asp:TextBox ID="txb_TerminalId" runat="server"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td class="fitwidth">refrenceNumber:</td>
                    <td class="fitwidth">
                        <asp:TextBox ID="txb_refrenceNumber" runat="server"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td class="fitwidth">reservationNumber:</td>
                    <td class="fitwidth">
                        <asp:TextBox ID="txb_reservationNumber" runat="server"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td class="fitwidth">transactionState:</td>
                    <td class="fitwidth">
                        <asp:TextBox ID="txb_transactionState" runat="server"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td class="fitwidth">traceNumber:</td>
                    <td class="fitwidth">
                        <asp:TextBox ID="txb_traceNumber" runat="server"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td class="fitwidth">Press Verify key to complete transaction</td>
                    <td class="fitwidth">
                        <asp:Button ID="btn_verify" runat="server" Text="Verify" OnClick="btn_verify_Click" />
                    </td>
                </tr>
            </table>
            <asp:TextBox ID="txb_Result" runat="server" Height="142px" Width="672px"></asp:TextBox>
        </div>
    </form>

</body>
</html>
