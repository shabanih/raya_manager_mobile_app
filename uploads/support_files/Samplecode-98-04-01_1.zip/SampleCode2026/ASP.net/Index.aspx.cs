﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlinePG_sample01
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Send_Click(object sender, EventArgs e)
        {
            string Token = "";
            var client = new RestClient("https://sep.shaparak.ir/onlinepg/onlinepg");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "ASP.NET_SessionId=qu51gu3nhsv4mhyvnozanrfa; TS017ebf2e=0112d175350249e4a374eed3ff7a3d56a5473bc705c1d9776dcdc0b86d54456987658788ecc092fd70850c69cddc164d58f01c27702b07a2f694ae90fddf47faa65362b1fd");
            var body = @"{" + "\n" +
            @"    ""Action"": ""Token""," + "\n" +
            @"    ""TerminalId"": " + txb_Termid.Text + ",\n" +
            @"    ""ResNum"": "+txb_Resnum.Text+",\n" +
            @"    ""Amount"": "+txb_Amount.Text+",\n" +
            @"    ""CellNumber"": "+txb_Cellnumber.Text+",\n" +
            @"    ""RedirectUrl"": '"+txb_RURL.Text+"'\n" +
            @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            if(response != null)
            {
                dynamic responseContent = JsonConvert.DeserializeObject(response.Content);
                if (responseContent.status==1)
                {
                    Token = responseContent.token;
                }
                else
                {
                    string errorCode = responseContent.errorCode;
                    string errorMessage = responseContent.errorDesc;
                    txb_Response.Text = errorMessage;
                }
            }

            NameValueCollection datacollection = new NameValueCollection();

            datacollection.Add("Token", Token);
            // if you want to use GetMethod -->datacollection.Add("GetMethod", "True");

            HttpHelper.RedirectAndPOST(this.Page, "https://sep.shaparak.ir/onlinepg/onlinepg", datacollection);

        }
    }
}