﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlinePG_sample01
{
    public partial class Result : System.Web.UI.Page
    {
        public string refrenceNumber = string.Empty;
        private string reservationNumber = string.Empty;
        private string transactionState = string.Empty;
        private string traceNumber = string.Empty;
        public string terminal = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            GetParams();
            if (!IsPostBack)
            {
                txb_TerminalId.Text = terminal;
                txb_refrenceNumber.Text = refrenceNumber;
                txb_reservationNumber.Text = reservationNumber;
                txb_transactionState.Text = transactionState;
                txb_traceNumber.Text = traceNumber;
            }

        }

        private void GetParams()
        {
            if (!IsPostBack)
            {
                try
                {
                    refrenceNumber = Request.Form["RefNum"].ToString();
                    reservationNumber = Request.Form["ResNum"].ToString();
                    transactionState = Request.Form["state"].ToString();
                    traceNumber = Request.Form["TraceNo"].ToString();
                    terminal = Request.Form["TerminalId"].ToString();
                }
                catch (Exception ex)
                {
                    lblResponse.Text = ex.Message.ToString();
                }
            }
        }

        protected void btn_verify_Click(object sender, EventArgs e)
        {
            string Termid=txb_TerminalId.Text;
            string referenceNumber=txb_refrenceNumber.Text;
            var client = new RestClient("https://sep.shaparak.ir/verifyTxnRandomSessionkey/ipg/VerifyTranscation");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            var body = @"{" + "\n" +
            @"  ""TerminalNumber"": '"+ Termid + "'," + "\n" +
            @"  ""RefNum"": '"+ referenceNumber + "'," + "\n" +
            @"  ""CellNumber"":""""," + "\n" +
            @"  ""NationalCode"" : """"," + "\n" +
            @"  ""IgnoreNationalcode"" : true" + "\n" +
            @"}" + "\n" +
            @"" + "\n" +
            @"";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            txb_Result.Text= response.Content;
        }
    }
}