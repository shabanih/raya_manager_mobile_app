﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Index.aspx.cs" Inherits="OnlinePG_sample01.Index" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <table>
                <tr>
                    <th>Item</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>TerminalNumber:</td>
                    <td>
                        <asp:TextBox ID="txb_Termid" runat="server" Text="12571198"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>Amount:</td>
                    <td>
                        <asp:TextBox ID="txb_Amount" runat="server" Text="12000"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>RedirectURL:</td>
                    <td>
                        <asp:TextBox ID="txb_RURL" runat="server" Text="https://localhost:44343/Result.aspx"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>Resnum:</td>
                    <td>
                        <asp:TextBox ID="txb_Resnum" runat="server" Text="1234"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>CellNumber:</td>
                    <td>
                        <asp:TextBox ID="txb_Cellnumber" runat="server" Text="9336514443"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Button ID="btn_Send" runat="server" Text="Send" OnClick="btn_Send_Click" />
                    </td>
                    <td></td>
                </tr>
            </table>
            <asp:TextBox ID="txb_Response" runat="server"></asp:TextBox>
        </div>
    </form>
</body>
</html>
